Animation assignment 3

numbers 1-5 switch the modes.

for number 2-5, you need to enter an integer as the number of masses that you want.

to run the program, type make to build it and then ./PhysicsSim to run the program

use WASD to move the camera and left click and move the mouse to rotate the camera
